let age=15;
age+=1;
age*=2;
console.log(age);
let message="il est "
if(age<18){
    console.log(message + " mineur" );
}else{
    console.log(message + " majeur" );
}
let films=["Avengers", "Peaky Blinders", "Batman"]
console.log(films[0])
console.log(films[1])
console.log(films[2])
films.push("Flash")
console.log(films)
films.pop()
console.log(films)
let indice=0
while(indice<films.length){
    let message=`L'indice à la position ${indice+1} est ${films[indice]}`
    console.log(message)
    indice++;

}
indice=0;
do{
    let message=`L'indice à la position ${indice+1} est ${films[indice]}`
    console.log(message)
    indice++;

}while(indice<films.length)

for(let indice=0; indice<films.length; indice+=1){
    let message=`L'indice à la position ${indice+1} est ${films[indice]}`
    console.log(message)
}
for(let cpt=5; cpt>=1; cpt--){
    let message="(position " + cpt + ")" 
    console.log(message)
}
function somme(a, b){
    let somme=a+b;
    let result="La somme de "+ a + "+" + b +"=" + somme
    return result;

}
console.log(somme(5, 2))
console.log(somme('a', 'b'))
let personne={
    age: 15,
    prenom: "INDA",
    nom: "Moustakim",
    moi(){
        console.log("Je suis " + this.prenom + " " + this.nom);


    }

}
console.log(personne)
console.log(personne.age)
personne.couleur="noir"
console.log(personne)
personne.moi()

console.log(document)
let titre=document.getElementById("titre")
console.log(titre)
titre.innerText="site depuis JS"
titre.style.backgroundColor="#ef0775"